package Model;

public class ProductGetSet {



}
