# Grocery-App

* Used Firebase
* Grocery Ordering App
* Add to Cart
* Checkout using razor-pay
